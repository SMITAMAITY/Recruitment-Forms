import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormOneRoutingModule } from './form-one-routing.module';
import { FormOneComponent } from './form-one.component';


@NgModule({
  declarations: [FormOneComponent],
  imports: [
    CommonModule,
    FormOneRoutingModule
    
  ]
})
export class FormOneModule { }
